This example code looks for joystick input in the event handler, and
reports any changes as a flood of info.
